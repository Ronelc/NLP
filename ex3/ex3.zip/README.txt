ronelharedim
Ronel Charedim (208917641)

omri2084
omri tuito (208472761)

EX: 3

FILES:
README.txt - This File
 exercise_blanks.py- q3
ex3_sol.pdf - q1,q2,q3 and compares 
resoults.txt - resoults file

* in function get_predictions_for_data we return prediction, accuracy and Loss
* in init function of DataManager class, we added few lines for represent the
  special subsets in dictionary