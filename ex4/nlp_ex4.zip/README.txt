ronelharedim
Ronel Charedim (208917641)

omri2084
omri tuito (208472761)

EX: 4

FILES:
README.txt - This File
MST_parser.py
NLP_ex4_sol.pdf
